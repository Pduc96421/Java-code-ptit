package java_code_ptit.J06003;

public class Sinh_vien {
    private String ma, ten, sdt, stt;

    public Sinh_vien(String ma, String ten, String sdt, String stt){
        this.ma = ma;
        this.ten = ten;
        this.sdt = sdt;
        this.stt = stt;
    }

    public String getstt(){
        return stt;
    }

    public String toString(){
        return this.ma + " " + this.ten + " " + this.sdt;
    }
}
