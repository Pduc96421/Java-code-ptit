package java_code_ptit.J06007;

public class Mon_hoc {
    private String ma, ten;
    
    public Mon_hoc(String ma, String ten){
        this.ma = ma;
        this.ten = ten;
    }
}
