package java_code_ptit.J06007;

public class Giang_vien {
    private String ma, ten;

    public Giang_vien(String ma, String ten){
        this.ma = ma;
        this.ten = ten;
    }

    public String getma(){
        return ma;
    }

    public String toString(){
        return this.ten;
    }
}
