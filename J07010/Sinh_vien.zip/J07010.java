package java_code_ptit.J07010;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class J07010 {
    public static void main(String[] args) throws FileNotFoundException{
        Scanner sc = new Scanner(new File("SV.in"));
        int n = sc.nextInt();
        ArrayList<Sinh_vien> sv = new ArrayList<>(); 
        for(int i = 1; i <= n; i++){
            sc.nextLine();
            Sinh_vien a = new Sinh_vien("B20DCCN" + String.format("%03d", i), sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextDouble());
            sv.add(a);
        }
        for(Sinh_vien x : sv){
            System.out.println(x);
        }
        sc.close();
    }
}
