package java_code_ptit.J07036;

public class Mon_hoc {
    private  String maMh, tenMh, tinchi;

    public Mon_hoc(String maMh, String tenMh, String tinchi){
        this.maMh = maMh;
        this.tenMh = tenMh;
        this.tinchi = tinchi;
    }

    public  String getMaMh(){
        return maMh;
    }

    public  String getTenMh(){
        return  tenMh;
    }


}
