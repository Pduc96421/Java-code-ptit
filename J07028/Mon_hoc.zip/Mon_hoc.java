package java_code_ptit.J07028;

public class Mon_hoc {
    private String maMon, tenMon;
    
    public Mon_hoc(String maMon, String tenMon){
        this.maMon = maMon;
        this.tenMon = tenMon;
    }

    public String getmaMon(){
        return maMon;
    }
}
