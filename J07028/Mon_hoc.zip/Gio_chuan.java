package java_code_ptit.J07028;

public class Gio_chuan {
    private String maGV, maMon;
    private double tongGio;

    public Gio_chuan(String maGV, String maMon, double tongGio){
        this.maGV = maGV;
        this.maMon = maMon;
        this.tongGio = tongGio;
    }

    public String getmaGv(){
        return maGV;
    }

    public double gettonggio(){
        return tongGio;
    }
}
