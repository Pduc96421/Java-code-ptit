package java_code_ptit.J07035;

public class Mon_hoc {
    @SuppressWarnings("unused")
    private String maMon, tenMon, sotinchi;

    public Mon_hoc(String maMon, String tenMon, String sotinchi){
        this.maMon = maMon;
        this.tenMon = tenMon;
        this.sotinchi = sotinchi;
    }

    public String getmaMon(){
        return maMon;
    }

    public String gettenMon(){
        return tenMon;
    }
}
