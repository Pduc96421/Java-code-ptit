package java_code_ptit.J07075;

public class Mon_hoc {
    private String maMon, tenMon, so_tin_chi;

    public Mon_hoc (String maMon, String tenMon, String so_tin_chi){
        this.maMon = maMon;
        this.tenMon = tenMon;
        this.so_tin_chi = so_tin_chi;
    }

    public String getmaMon(){
        return maMon;
    }

    public String gettenMon(){
        return tenMon;
    }
}
