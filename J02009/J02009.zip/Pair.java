package java_code_ptit.J02009;

public class Pair {
    private int a, b;

    public Pair(int a, int b){
        this.a = a;
        this.b = b;
    }

    public int geta(){
        return a;
    }

    public int getb(){
        return b;
    }
}
