package java_code_ptit.J07018;

import java.text.SimpleDateFormat;

public class Sinh_vien {
    private String maSv, tenSv, lop, bd;
    private double gpa;

    public Sinh_vien(String maSv, String tenSv, String lop, String bd, double gpa){
        this.maSv = maSv;
        this.tenSv = tenSv;
        this.lop = lop;
        this.bd = bd;
        this.gpa = gpa;
    }

    public void chuanhoa(){
        String[] a = this.tenSv.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for(String x : a){
            sb.append(Character.toUpperCase(x.charAt(0)));
            sb.append(x.substring(1).toLowerCase());
            sb.append(" ");
        }
        this.tenSv = sb.toString();
    }

    public String toString(){
        chuanhoa();
        String ngaysinh = new SimpleDateFormat("dd/MM/yyyy").format(this.bd);
        return this.maSv + " " + this.tenSv + " " + this.lop + " " + ngaysinh + " " + String.format("%.2f", this.gpa);
    }
}
