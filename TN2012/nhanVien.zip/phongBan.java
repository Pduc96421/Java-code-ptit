package java_code_ptit.TN2012;

public class phongBan {
    private String maPb, tenPb;

    public phongBan(String maPb, String tenPb){
        this.maPb = maPb;
        this.tenPb = tenPb;
    }

    public String getMaPb(){
        return maPb;
    }

    public String getTenPb(){
        return tenPb;
    }
}
