package java_code_ptit.J06008;

public class Mon_hoc {
    private String ma, ten;

    public Mon_hoc(String ma, String ten){
        this.ma = ma;
        this.ten = ten;
    }

    public String getma(){
        return ma;
    }

    public String getten(){
        return ten;
    }
}
