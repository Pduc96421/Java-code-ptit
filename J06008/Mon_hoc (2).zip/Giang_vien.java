package java_code_ptit.J06008;

public class Giang_vien {
    private String ma, ten, tenMh;
    private double gio;

    public Giang_vien(String ma, String ten){
        this.ma = ma;
        this.ten = ten;
    }

    public String getma(){
        return ma;
    }

    public String getten(){
        return ten;
    }

    public double getgio(){
        return gio;
    }

    public void setgio(double gio){
        this.gio = gio;
    }

    public void settenMh(String tenMh){
        this.tenMh = tenMh;
    }
    
    public String toString(){
        return this.tenMh + " " + String.format("%.2f", gio);
    }
}
